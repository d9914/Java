package edu.altierd.Assign06;

public interface Drawable {
    public abstract void draw(CharImage map);
}
